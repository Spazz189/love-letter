// CHANGE THIS ONE LINE if you want the music button to open a different official music page.
const SONG_URL = "https://www.youtube.com/results?search_query=End+Of+The+Road+Boyz+II+Men+official";

function showPage(number) {
  document.querySelectorAll(".screen").forEach(s => s.classList.remove("active"));
  const target = number === 0 ? "home" : `page${number}`;
  document.getElementById(target).classList.add("active");
  window.scrollTo({top: 0, behavior: "smooth"});
}

function openSong() {
  window.open(SONG_URL, "_blank", "noopener,noreferrer");
}

// Gentle falling flower petals
const petalBox = document.querySelector(".petals");
const flowers = ["🌸", "🌷", "🌺", "✿", "❀"];

function makePetal() {
  const petal = document.createElement("span");
  petal.className = "petal";
  petal.textContent = flowers[Math.floor(Math.random() * flowers.length)];
  petal.style.left = Math.random() * 100 + "vw";
  petal.style.fontSize = (12 + Math.random() * 14) + "px";
  petal.style.animationDuration = (7 + Math.random() * 8) + "s";
  petal.style.setProperty("--drift", (Math.random() * 180 - 90) + "px");
  petalBox.appendChild(petal);
  setTimeout(() => petal.remove(), 16000);
}

setInterval(makePetal, 650);
